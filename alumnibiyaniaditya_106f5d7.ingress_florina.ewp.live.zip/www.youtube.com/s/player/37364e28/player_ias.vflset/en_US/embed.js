(function(g) {
    var window = this;
    'use strict';
    var ziH = function(m) {
            m.mutedAutoplay = !1;
            m.endSeconds = NaN;
            m.limitedPlaybackDurationInSeconds = NaN;
            g.rH(m)
        },
        eid = function() {
            return {
                D: "svg",
                Y: {
                    height: "100%",
                    version: "1.1",
                    viewBox: "0 0 110 26",
                    width: "100%"
                },
                Z: [{
                    D: "path",
                    dT: !0,
                    T: "ytp-svg-fill",
                    Y: {
                        d: "M 16.68,.99 C 13.55,1.03 7.02,1.16 4.99,1.68 c -1.49,.4 -2.59,1.6 -2.99,3 -0.69,2.7 -0.68,8.31 -0.68,8.31 0,0 -0.01,5.61 .68,8.31 .39,1.5 1.59,2.6 2.99,3 2.69,.7 13.40,.68 13.40,.68 0,0 10.70,.01 13.40,-0.68 1.5,-0.4 2.59,-1.6 2.99,-3 .69,-2.7 .68,-8.31 .68,-8.31 0,0 .11,-5.61 -0.68,-8.31 -0.4,-1.5 -1.59,-2.6 -2.99,-3 C 29.11,.98 18.40,.99 18.40,.99 c 0,0 -0.67,-0.01 -1.71,0 z m 72.21,.90 0,21.28 2.78,0 .31,-1.37 .09,0 c .3,.5 .71,.88 1.21,1.18 .5,.3 1.08,.40 1.68,.40 1.1,0 1.99,-0.49 2.49,-1.59 .5,-1.1 .81,-2.70 .81,-4.90 l 0,-2.40 c 0,-1.6 -0.11,-2.90 -0.31,-3.90 -0.2,-0.89 -0.5,-1.59 -1,-2.09 -0.5,-0.4 -1.10,-0.59 -1.90,-0.59 -0.59,0 -1.18,.19 -1.68,.49 -0.49,.3 -1.01,.80 -1.21,1.40 l 0,-7.90 -3.28,0 z m -49.99,.78 3.90,13.90 .18,6.71 3.31,0 0,-6.71 3.87,-13.90 -3.37,0 -1.40,6.31 c -0.4,1.89 -0.71,3.19 -0.81,3.99 l -0.09,0 c -0.2,-1.1 -0.51,-2.4 -0.81,-3.99 l -1.37,-6.31 -3.40,0 z m 29.59,0 0,2.71 3.40,0 0,17.90 3.28,0 0,-17.90 3.40,0 c 0,0 .00,-2.71 -0.09,-2.71 l -9.99,0 z m -53.49,5.12 8.90,5.18 -8.90,5.09 0,-10.28 z m 89.40,.09 c -1.7,0 -2.89,.59 -3.59,1.59 -0.69,.99 -0.99,2.60 -0.99,4.90 l 0,2.59 c 0,2.2 .30,3.90 .99,4.90 .7,1.1 1.8,1.59 3.5,1.59 1.4,0 2.38,-0.3 3.18,-1 .7,-0.7 1.09,-1.69 1.09,-3.09 l 0,-0.5 -2.90,-0.21 c 0,1 -0.08,1.6 -0.28,2 -0.1,.4 -0.5,.62 -1,.62 -0.3,0 -0.61,-0.11 -0.81,-0.31 -0.2,-0.3 -0.30,-0.59 -0.40,-1.09 -0.1,-0.5 -0.09,-1.21 -0.09,-2.21 l 0,-0.78 5.71,-0.09 0,-2.62 c 0,-1.6 -0.10,-2.78 -0.40,-3.68 -0.2,-0.89 -0.71,-1.59 -1.31,-1.99 -0.7,-0.4 -1.48,-0.59 -2.68,-0.59 z m -50.49,.09 c -1.09,0 -2.01,.18 -2.71,.68 -0.7,.4 -1.2,1.12 -1.49,2.12 -0.3,1 -0.5,2.27 -0.5,3.87 l 0,2.21 c 0,1.5 .10,2.78 .40,3.78 .2,.9 .70,1.62 1.40,2.12 .69,.5 1.71,.68 2.81,.78 1.19,0 2.08,-0.28 2.78,-0.68 .69,-0.4 1.09,-1.09 1.49,-2.09 .39,-1 .49,-2.30 .49,-3.90 l 0,-2.21 c 0,-1.6 -0.2,-2.87 -0.49,-3.87 -0.3,-0.89 -0.8,-1.62 -1.49,-2.12 -0.7,-0.5 -1.58,-0.68 -2.68,-0.68 z m 12.18,.09 0,11.90 c -0.1,.3 -0.29,.48 -0.59,.68 -0.2,.2 -0.51,.31 -0.81,.31 -0.3,0 -0.58,-0.10 -0.68,-0.40 -0.1,-0.3 -0.18,-0.70 -0.18,-1.40 l 0,-10.99 -3.40,0 0,11.21 c 0,1.4 .18,2.39 .68,3.09 .49,.7 1.21,1 2.21,1 1.4,0 2.48,-0.69 3.18,-2.09 l .09,0 .31,1.78 2.59,0 0,-14.99 c 0,0 -3.40,.00 -3.40,-0.09 z m 17.31,0 0,11.90 c -0.1,.3 -0.29,.48 -0.59,.68 -0.2,.2 -0.51,.31 -0.81,.31 -0.3,0 -0.58,-0.10 -0.68,-0.40 -0.1,-0.3 -0.21,-0.70 -0.21,-1.40 l 0,-10.99 -3.40,0 0,11.21 c 0,1.4 .21,2.39 .71,3.09 .5,.7 1.18,1 2.18,1 1.39,0 2.51,-0.69 3.21,-2.09 l .09,0 .28,1.78 2.62,0 0,-14.99 c 0,0 -3.40,.00 -3.40,-0.09 z m 20.90,2.09 c .4,0 .58,.11 .78,.31 .2,.3 .30,.59 .40,1.09 .1,.5 .09,1.21 .09,2.21 l 0,1.09 -2.5,0 0,-1.09 c 0,-1 -0.00,-1.71 .09,-2.21 0,-0.4 .11,-0.8 .31,-1 .2,-0.3 .51,-0.40 .81,-0.40 z m -50.49,.12 c .5,0 .8,.18 1,.68 .19,.5 .28,1.30 .28,2.40 l 0,4.68 c 0,1.1 -0.08,1.90 -0.28,2.40 -0.2,.5 -0.5,.68 -1,.68 -0.5,0 -0.79,-0.18 -0.99,-0.68 -0.2,-0.5 -0.31,-1.30 -0.31,-2.40 l 0,-4.68 c 0,-1.1 .11,-1.90 .31,-2.40 .2,-0.5 .49,-0.68 .99,-0.68 z m 39.68,.09 c .3,0 .61,.10 .81,.40 .2,.3 .27,.67 .37,1.37 .1,.6 .12,1.51 .12,2.71 l .09,1.90 c 0,1.1 .00,1.99 -0.09,2.59 -0.1,.6 -0.19,1.08 -0.49,1.28 -0.2,.3 -0.50,.40 -0.90,.40 -0.3,0 -0.51,-0.08 -0.81,-0.18 -0.2,-0.1 -0.39,-0.29 -0.59,-0.59 l 0,-8.5 c .1,-0.4 .29,-0.7 .59,-1 .3,-0.3 .60,-0.40 .90,-0.40 z"
                    }
                }]
            }
        },
        dqd = function() {
            return {
                D: "svg",
                Y: {
                    fill: "none",
                    height: "100%",
                    viewBox: "0 0 143 51",
                    width: "100%"
                },
                Z: [{
                    D: "path",
                    Y: {
                        d: "M58.37 41.39H62.79V27.23C62.79 23.03 62.69 18.69 62.43 13.59H62.93L63.69 16.89L68.67 41.39H73.17L78.07 16.89L78.89 13.59H79.37C79.15 18.45 79.03 22.89 79.03 27.23V41.39H83.45V8.79H75.95L73.41 20.81C72.35 25.85 71.51 32.01 71.01 35.19H70.73C70.33 31.95 69.49 25.81 68.41 20.85L65.81 8.79H58.37V41.39Z",
                        fill: "white"
                    }
                }, {
                    D: "path",
                    Y: {
                        d: "M91.45 41.73C93.91 41.73 95.83 40.59 97.17 38.13H97.35L97.69 41.39H101.43V17.73H96.47V36.61C95.91 37.67 94.81 38.29 93.73 38.29C92.33 38.29 91.89 37.17 91.89 35.13V17.73H86.93V35.43C86.93 39.49 88.19 41.73 91.45 41.73Z",
                        fill: "white"
                    }
                }, {
                    D: "path",
                    Y: {
                        d: "M110.79 41.89C115.15 41.89 117.75 39.83 117.75 35.65C117.75 31.79 115.93 30.39 111.85 27.47C109.67 25.91 108.39 25.09 108.39 22.95C108.39 21.47 109.27 20.61 110.89 20.61C112.69 20.61 113.33 21.81 113.33 25.29L117.45 25.07C117.77 19.57 115.71 17.23 110.97 17.23C106.57 17.23 104.17 19.27 104.17 23.45C104.17 27.25 105.97 28.83 108.93 31.03C111.89 33.23 113.55 34.53 113.55 36.23C113.55 37.75 112.51 38.61 111.01 38.61C109.13 38.61 108.11 36.97 108.29 34.41L104.21 34.49C103.51 39.25 105.89 41.89 110.79 41.89Z",
                        fill: "white"
                    }
                }, {
                    D: "path",
                    Y: {
                        d: "M122.5 14.59C124.22 14.59 125.04 13.99 125.04 11.59C125.04 9.33 124.16 8.65 122.5 8.65C120.84 8.65 119.94 9.27 119.94 11.59C119.94 13.99 120.82 14.59 122.5 14.59ZM120.2 41.39H125V17.73H120.2V41.39Z",
                        fill: "white"
                    }
                }, {
                    D: "path",
                    Y: {
                        d: "M134.95 41.79C137.31 41.79 138.63 41.49 139.71 40.47C141.31 39.01 141.97 36.63 141.85 33.11L137.41 32.87C137.41 36.87 136.81 38.45 135.03 38.45C133.13 38.45 132.77 36.45 132.77 31.97V27.21C132.77 22.41 133.23 20.51 135.07 20.51C136.67 20.51 137.29 22.01 137.29 26.47L141.65 26.15C141.97 22.93 141.59 20.29 140.09 18.83C139.01 17.77 137.37 17.29 135.15 17.29C129.65 17.29 127.75 20.73 127.75 28.03V31.17C127.75 38.47 129.23 41.79 134.95 41.79Z",
                        fill: "white"
                    }
                }, {
                    D: "path",
                    Y: {
                        "clip-rule": "evenodd",
                        d: "M24.99 49C29.74 49.00 34.38 47.59 38.32 44.95C42.27 42.32 45.35 38.57 47.17 34.18C48.98 29.80 49.46 24.97 48.53 20.32C47.61 15.66 45.32 11.38 41.97 8.03C38.61 4.67 34.33 2.38 29.68 1.46C25.02 .53 20.20 1.01 15.81 2.82C11.43 4.64 7.68 7.71 5.04 11.66C2.40 15.61 1 20.25 1 25C0.99 28.15 1.61 31.27 2.82 34.18C4.03 37.09 5.79 39.74 8.02 41.97C10.25 44.19 12.89 45.96 15.81 47.17C18.72 48.37 21.84 49 24.99 49ZM24.99 12.36C27.49 12.36 29.94 13.10 32.02 14.48C34.10 15.87 35.72 17.84 36.68 20.15C37.64 22.46 37.89 25.01 37.41 27.46C36.92 29.91 35.72 32.17 33.95 33.94C32.18 35.70 29.93 36.91 27.48 37.40C25.02 37.89 22.48 37.64 20.17 36.68C17.86 35.72 15.88 34.10 14.50 32.02C13.11 29.94 12.37 27.50 12.37 25C12.37 21.65 13.70 18.44 16.07 16.07C18.43 13.70 21.64 12.37 24.99 12.36ZM24.99 10.43C22.11 10.43 19.29 11.28 16.89 12.88C14.50 14.48 12.63 16.76 11.53 19.42C10.42 22.09 10.13 25.02 10.70 27.85C11.26 30.67 12.65 33.27 14.69 35.31C16.73 37.35 19.32 38.73 22.15 39.30C24.98 39.86 27.91 39.57 30.57 38.46C33.23 37.36 35.51 35.49 37.11 33.09C38.71 30.70 39.57 27.88 39.56 25C39.56 23.08 39.19 21.19 38.46 19.42C37.72 17.65 36.65 16.04 35.30 14.69C33.94 13.34 32.34 12.27 30.57 11.53C28.80 10.80 26.90 10.43 24.99 10.43ZM32.63 24.99L20.36 32.09V17.91L32.63 24.99Z",
                        fill: "white",
                        "fill-rule": "evenodd"
                    }
                }]
            }
        },
        t74 = function(m) {
            g.f.call(this, {
                D: "div",
                T: "ytp-related-on-error-overlay"
            });
            var c = this;
            this.api = m;
            this.B = this.V = 0;
            this.L = new g.nm(this);
            this.j = [];
            this.suggestionData = [];
            this.columns = this.containerWidth = 0;
            this.title = new g.f({
                D: "h2",
                T: "ytp-related-title",
                E8: "{{title}}"
            });
            this.previous = new g.f({
                D: "button",
                U8: ["ytp-button", "ytp-previous"],
                Y: {
                    "aria-label": "Show previous suggested videos"
                },
                Z: [g.lV()]
            });
            this.W = new g.fY(function(R) {
                c.suggestions.element.scrollLeft = -R
            });
            this.K = this.scrollPosition = 0;
            this.X = !0;
            this.next = new g.f({
                D: "button",
                U8: ["ytp-button", "ytp-next"],
                Y: {
                    "aria-label": "Show more suggested videos"
                },
                Z: [g.qS()]
            });
            g.r(this, this.L);
            m = m.J();
            this.api.G("embeds_web_enable_pause_overlay_rounding") && g.ov(this.element, "ytp-error-overlay-round-corners");
            this.N = m.L;
            g.r(this, this.title);
            this.title.s8(this.element);
            this.suggestions = new g.f({
                D: "div",
                T: "ytp-suggestions"
            });
            g.r(this, this.suggestions);
            this.suggestions.s8(this.element);
            g.r(this, this.previous);
            this.previous.s8(this.element);
            this.previous.listen("click", this.Xj, this);
            g.r(this, this.W);
            for (var W = {
                    vQ: 0
                }; W.vQ < 16; W = {
                    vQ: W.vQ
                }, W.vQ++) {
                var A = new g.f({
                    D: "a",
                    T: "ytp-suggestion-link",
                    Y: {
                        href: "{{link}}",
                        target: m.W,
                        "aria-label": "{{aria_label}}"
                    },
                    Z: [{
                        D: "div",
                        T: "ytp-suggestion-image",
                        Z: [{
                            D: "div",
                            Y: {
                                "data-is-live": "{{is_live}}"
                            },
                            T: "ytp-suggestion-duration",
                            E8: "{{duration}}"
                        }]
                    }, {
                        D: "div",
                        T: "ytp-suggestion-title",
                        Y: {
                            title: "{{hover_title}}"
                        },
                        E8: "{{title}}"
                    }, {
                        D: "div",
                        T: "ytp-suggestion-author",
                        E8: "{{views_or_author}}"
                    }]
                });
                g.r(this, A);
                A.s8(this.suggestions.element);
                var p = A.Lf("ytp-suggestion-link");
                g.JU(p, "transitionDelay", W.vQ / 20 + "s");
                this.L.S(p, "click", function(R) {
                    return function(L) {
                        var M = R.vQ,
                            b = c.suggestionData[M],
                            N = b.sessionData;
                        g.lh(c.api.J()) && c.api.G("web_player_log_click_before_generating_ve_conversion_params") ? (c.api.logClick(c.j[M].element), M = b.rG(), b = {}, g.qT(c.api, b), M = g.PX(M, b), g.mq(M, c.api, L)) : g.XP(L, c.api, c.N, N || void 0) && c.api.A$(b.videoId, N, b.playlistId)
                    }
                }(W));
                this.j.push(A)
            }
            g.r(this, this.next);
            this.next.s8(this.element);
            this.next.listen("click", this.GR, this);
            this.L.S(this.api, "videodatachange", this.onVideoDataChange);
            this.resize(this.api.FY().getPlayerSize());
            this.onVideoDataChange();
            this.show()
        },
        GXS = function(m, c) {
            if (m.api.J().G("web_player_log_click_before_generating_ve_conversion_params"))
                for (var W = Math.floor(-m.scrollPosition / (m.K + m.V)), A = Math.min(W + m.columns, m.suggestionData.length) - 1; W <= A; W++) m.api.logVisibility(m.j[W].element, c)
        },
        DqH = function(m) {
            m.next.element.style.bottom =
                m.B + "px";
            m.previous.element.style.bottom = m.B + "px";
            var c = m.scrollPosition,
                W = m.containerWidth - m.suggestionData.length * (m.K + m.V);
            g.wY(m.element, "ytp-scroll-min", c >= 0);
            g.wY(m.element, "ytp-scroll-max", c <= W)
        },
        Kdh = function(m) {
            for (var c = 0; c < m.suggestionData.length; c++) {
                var W = m.suggestionData[c],
                    A = m.j[c],
                    p = W.shortViewCount ? W.shortViewCount : W.author,
                    R = W.rG(),
                    L = m.api.J();
                if (g.lh(L) && !L.G("web_player_log_click_before_generating_ve_conversion_params")) {
                    var M = {};
                    g.AM(m.api, "addEmbedsConversionTrackingParams", [M]);
                    R = g.PX(R, M)
                }
                A.element.style.display = "";
                M = A.Lf("ytp-suggestion-title");
                g.xb.test(W.title) ? M.dir = "rtl" : g.IQX.test(W.title) && (M.dir = "ltr");
                M = A.Lf("ytp-suggestion-author");
                g.xb.test(p) ? M.dir = "rtl" : g.IQX.test(p) && (M.dir = "ltr");
                A.update({
                    views_or_author: p,
                    duration: W.isLivePlayback ? "Live" : W.lengthSeconds ? g.ek(W.lengthSeconds) : "",
                    link: R,
                    hover_title: W.title,
                    title: W.title,
                    aria_label: W.ariaLabel || null,
                    is_live: W.isLivePlayback
                });
                p = W.kI();
                A.Lf("ytp-suggestion-image").style.backgroundImage = p ? "url(" + p + ")" : "";
                L.G("web_player_log_click_before_generating_ve_conversion_params") && (m.api.createServerVe(A.element, A), (W = (W = W.sessionData) && W.itct) && m.api.setTrackingParams(A.element, W))
            }
            for (; c < m.j.length; c++) m.j[c].element.style.display = "none";
            DqH(m)
        },
        UE = function(m) {
            g.PL.call(this, m);
            var c = this;
            this.j = null;
            var W = m.J(),
                A = {
                    target: W.W
                },
                p = ["ytp-small-redirect"];
            W.K ? p.push("no-link") : (W = g.kv(W), A.href = W, A["aria-label"] = "Visit YouTube to search for more videos");
            var R = new g.f({
                D: "a",
                U8: p,
                Y: A,
                Z: [{
                    D: "svg",
                    Y: {
                        fill: "#fff",
                        height: "100%",
                        viewBox: "0 0 24 24",
                        width: "100%"
                    },
                    Z: [{
                        D: "path",
                        Y: {
                            d: "M0 0h24v24H0V0z",
                            fill: "none"
                        }
                    }, {
                        D: "path",
                        Y: {
                            d: "M21.58 7.19c-.23-.86-.91-1.54-1.77-1.77C18.25 5 12 5 12 5s-6.25 0-7.81.42c-.86.23-1.54.91-1.77 1.77C2 8.75 2 12 2 12s0 3.25.42 4.81c.23.86.91 1.54 1.77 1.77C5.75 19 12 19 12 19s6.25 0 7.81-.42c.86-.23 1.54-.91 1.77-1.77C22 15.25 22 12 22 12s0-3.25-.42-4.81zM10 15V9l5.2 3-5.2 3z"
                        }
                    }]
                }]
            });
            R.s8(this.element);
            m.createClientVe(R.element, this, 178053);
            this.S(R.element, "click", function(L) {
                BGa(c, L, R.element)
            });
            g.r(this, R);
            m.J().K || (this.j = new t74(m), this.j.s8(this.element), g.r(this, this.j));
            this.S(m, "videodatachange", function() {
                c.show()
            });
            this.resize(this.api.FY().getPlayerSize())
        },
        BGa = function(m, c, W) {
            c.preventDefault();
            m.api.logClick(W);
            c = W.getAttribute("href");
            W = {};
            g.AM(m.api, "addEmbedsConversionTrackingParams", [W]);
            c = g.Dd(W) ? c : g.PX(c, W);
            g.h7(window, c)
        },
        vii = function(m, c) {
            m.Lf("ytp-error-content").style.paddingTop = "0px";
            var W = m.Lf("ytp-error-content"),
                A = W.clientHeight;
            m.j && m.j.resize(c, c.height - A);
            W.style.paddingTop = (c.height - (m.j ? m.j.element.clientHeight : 0)) / 2 - A / 2 + "px"
        },
        uRi = function(m, c) {
            var W = m.api.J(),
                A;
            c.reason && (jCG(c.reason) ? A = g.Hi(c.reason) : A = g.Ua(g.V9(c.reason)), m.jK(A, "content"));
            var p;
            c.subreason && (jCG(c.subreason) ? p = g.Hi(c.subreason) : p = g.Ua(g.V9(c.subreason)), m.jK(p, "subreason"));
            if (c.proceedButton && c.proceedButton.buttonRenderer) {
                A = m.Lf("ytp-error-content-wrap-subreason");
                c = c.proceedButton.buttonRenderer;
                var R = g.Ag("A");
                if (c.text && c.text.simpleText && (p = c.text.simpleText, R.textContent = p, !ayr(A, p) && (!W.K || W.embedsErrorLinks))) {
                    var L;
                    W = (L = g.h(c == null ? void 0 : c.navigationEndpoint, g.rB)) == null ?
                        void 0 : L.url;
                    var M;
                    L = (M = g.h(c == null ? void 0 : c.navigationEndpoint, g.rB)) == null ? void 0 : M.target;
                    W && (R.setAttribute("href", W), m.api.createClientVe(R, m, 178424), m.S(R, "click", function(b) {
                        BGa(m, b, R)
                    }));
                    L && R.setAttribute("target", L);
                    M = g.Ag("DIV");
                    M.appendChild(R);
                    A.appendChild(M)
                }
            }
        },
        jCG = function(m) {
            if (m.runs)
                for (var c = 0; c < m.runs.length; c++)
                    if (m.runs[c].navigationEndpoint) return !0;
            return !1
        },
        ayr = function(m, c) {
            m = g.id("A", m);
            for (var W = 0; W < m.length; W++)
                if (m[W].textContent === c) return !0;
            return !1
        },
        nid = function(m, c) {
            g.f.call(this, {
                D: "a",
                U8: ["ytp-impression-link"],
                Y: {
                    target: "{{target}}",
                    href: "{{url}}",
                    "aria-label": "Watch on YouTube"
                },
                Z: [{
                    D: "div",
                    T: "ytp-impression-link-content",
                    Y: {
                        "aria-hidden": "true"
                    },
                    Z: [{
                        D: "div",
                        T: "ytp-impression-link-text",
                        E8: "Watch on"
                    }, {
                        D: "div",
                        T: "ytp-impression-link-logo",
                        E8: "{{logoSvg}}"
                    }]
                }]
            });
            this.api = m;
            this.j = c;
            this.updateValue("target", m.J().W);
            this.S(m, "videodatachange", this.onVideoDataChange);
            this.S(this.api, "presentingplayerstatechange", this.X$);
            this.S(this.api, "videoplayerreset", this.Zp);
            this.S(this.element,
                "click", this.onClick);
            this.onVideoDataChange();
            this.Zp()
        },
        rgS = function(m) {
            var c = {};
            g.AM(m.api, "addEmbedsConversionTrackingParams", [c]);
            m = m.api.getVideoUrl();
            return m = g.PX(m, c)
        },
        kH = function(m) {
            g.f.call(this, {
                D: "div",
                U8: ["ytp-mobile-a11y-hidden-seek-button"],
                Z: [{
                    D: "button",
                    U8: ["ytp-mobile-a11y-hidden-seek-button-rewind", "ytp-button"],
                    Y: {
                        "aria-label": "Rewind 10 seconds",
                        "aria-hidden": "false"
                    }
                }, {
                    D: "button",
                    U8: ["ytp-mobile-a11y-hidden-seek-button-forward", "ytp-button"],
                    Y: {
                        "aria-label": "Fast forward 10 seconds",
                        "aria-hidden": "false"
                    }
                }]
            });
            this.api = m;
            this.j = this.Lf("ytp-mobile-a11y-hidden-seek-button-rewind");
            this.forwardButton = this.Lf("ytp-mobile-a11y-hidden-seek-button-forward");
            this.api.createClientVe(this.j, this,
                141902);
            this.api.createClientVe(this.forwardButton, this, 141903);
            this.S(this.api, "presentingplayerstatechange", this.X$);
            this.S(this.j, "click", this.V);
            this.S(this.forwardButton, "click", this.K);
            this.X$()
        },
        XC = function(m) {
            g.f.call(this, {
                D: "div",
                T: "ytp-muted-autoplay-endscreen-overlay",
                Z: [{
                    D: "div",
                    T: "ytp-muted-autoplay-end-panel",
                    Z: [{
                        D: "button",
                        U8: ["ytp-muted-autoplay-end-text", "ytp-button"],
                        E8: "{{text}}"
                    }]
                }]
            });
            this.api = m;
            this.L = this.Lf("ytp-muted-autoplay-end-panel");
            this.V = !1;
            this.api.createClientVe(this.element, this, 52428);
            this.S(this.api, "presentingplayerstatechange", this.K);
            this.S(m, "onMutedAutoplayStarts", this.onMutedAutoplayStarts);
            this.listen("click", this.onClick);
            this.hide()
        },
        m_ = function(m) {
            var c = m.J();
            g.f.call(this, {
                D: "a",
                U8: ["ytp-watermark", "yt-uix-sessionlink"],
                Y: {
                    target: c.W,
                    href: "{{url}}",
                    "aria-label": g.xg("Watch on $WEBSITE", {
                        WEBSITE: g.nX(c)
                    }),
                    "data-sessionlink": "feature=player-watermark"
                },
                E8: "{{logoSvg}}"
            });
            this.api = m;
            this.j = null;
            this.V = !1;
            this.state = m.getPlayerStateObject();
            this.S(m, "videodatachange", this.onVideoDataChange);
            this.S(m, "presentingplayerstatechange", this.onStateChange);
            this.S(m, "appresize", this.Fz);
            this.onVideoDataChange();
            this.aB(this.state);
            this.Fz(m.FY().getPlayerSize())
        },
        hii = function(m) {
            var c = m.api.getVideoData(),
                W = m.api.J();
            W = W.HB && !g.U(m.state, 2) && !g.i7(m.api.getVideoData(1)) && !(W.G("embeds_enable_emc3ds_woyt_counterfactual") && m.api.getPlayerStateObject().isCued());
            c.mutedAutoplay || m.My(W);
            m.api.logVisibility(m.element, W)
        },
        Eir = function(m) {
            g.f.call(this, {
                D: "div",
                T: "ytp-muted-autoplay-overlay",
                Z: [{
                    D: "div",
                    T: "ytp-muted-autoplay-bottom-buttons",
                    Z: [{
                        D: "button",
                        U8: ["ytp-muted-autoplay-equalizer", "ytp-button"],
                        Y: {
                            "aria-label": "Muted Playback Indicator"
                        },
                        Z: [{
                            D: "div",
                            U8: ["ytp-muted-autoplay-equalizer-icon"],
                            Z: [{
                                D: "svg",
                                Y: {
                                    height: "100%",
                                    version: "1.1",
                                    viewBox: "-4 -4 24 24",
                                    width: "100%"
                                },
                                Z: [{
                                    D: "g",
                                    Y: {
                                        fill: "#fff"
                                    },
                                    Z: [{
                                            D: "rect",
                                            T: "ytp-equalizer-bar-left",
                                            Y: {
                                                height: "9",
                                                width: "4",
                                                x: "1",
                                                y: "7"
                                            }
                                        }, {
                                            D: "rect",
                                            T: "ytp-equalizer-bar-middle",
                                            Y: {
                                                height: "14",
                                                width: "4",
                                                x: "6",
                                                y: "2"
                                            }
                                        },
                                        {
                                            D: "rect",
                                            T: "ytp-equalizer-bar-right",
                                            Y: {
                                                height: "12",
                                                width: "4",
                                                x: "11",
                                                y: "4"
                                            }
                                        }
                                    ]
                                }]
                            }]
                        }]
                    }]
                }]
            });
            var c = this;
            this.api = m;
            this.bottomButtons = this.Lf("ytp-muted-autoplay-bottom-buttons");
            this.K = new g.Rv(this.q8q, 4E3, this);
            this.V = !1;
            m.createClientVe(this.element, this, 39306);
            this.S(m, "presentingplayerstatechange", this.dY);
            this.S(m, "onMutedAutoplayStarts", function() {
                sCG(c);
                c.dY();
                Sn4(c);
                c.V = !1
            });
            this.S(m, "onAutoplayBlocked", this.onAutoplayBlocked);
            this.listen("click", this.onClick);
            this.S(m, "onMutedAutoplayEnds", this.onMutedAutoplayEnds);
            this.hide();
            m.isMutedByEmbedsMutedAutoplay() && (sCG(this), this.dY(), Sn4(this));
            g.r(this, this.K)
        },
        Sn4 = function(m) {
            m.d4 && m.j && (m.j.show(), m.K.start())
        },
        sCG = function(m) {
            m.watermark || (m.watermark = new m_(m.api), g.r(m, m.watermark), m.watermark.s8(m.bottomButtons, 0), g.wY(m.watermark.element, "ytp-muted-autoplay-watermark", !0), m.j = new g.Rd(m.watermark, 0, !0, 100), g.r(m,
                m.j))
        },
        cu = function(m) {
            g.f.call(this, {
                D: "div",
                T: "ytp-pause-overlay",
                Y: {
                    tabIndex: "-1"
                }
            });
            var c = this;
            this.api = m;
            this.K = new g.nm(this);
            this.L = new g.Rd(this, 1E3, !1, 100, function() {
                c.j.V = !1
            }, function() {
                c.j.V = !0
            });
            this.V = !1;
            this.expandButton = new g.f({
                D: "button",
                U8: ["ytp-button", "ytp-expand"],
                E8: this.api.isEmbedsShortsMode() ? "More shorts" : "More videos"
            });
            m.J().controlsType === "0" && g.ov(m.getRootNode(), "ytp-pause-overlay-controls-hidden");
            this.api.G("embeds_web_enable_pause_overlay_rounding") && g.ov(this.element, "ytp-pause-overlay-round-corners");
            g.r(this, this.K);
            g.r(this, this.L);
            var W = new g.f({
                D: "button",
                U8: ["ytp-button", "ytp-collapse"],
                Y: {
                    "aria-label": this.api.isEmbedsShortsMode() ? "Hide more shorts" : "Hide more videos"
                },
                Z: [{
                    D: "div",
                    T: "ytp-collapse-icon",
                    Z: [g.KG()]
                }]
            });
            g.r(this, W);
            W.s8(this.element);
            W.listen("click", this.B, this);
            g.r(this, this.expandButton);
            this.expandButton.s8(this.element);
            this.expandButton.listen("click", this.X, this);
            this.j = new g.ia(m);
            g.r(this, this.j);
            this.j.V = !1;
            this.j.s8(this.element);
            this.api.isEmbedsShortsMode() ? this.api.createClientVe(this.element, this, 157212) : this.api.createClientVe(this.element, this, 172777);
            this.K.S(this.api, "presentingplayerstatechange", this.Ps);
            this.K.S(this.api, "videodatachange",
                this.Ps);
            this.hide()
        },
        Wu = function(m) {
            g.f.call(this, {
                D: "div",
                U8: ["ytp-player-content", "ytp-iv-player-content"],
                Z: [{
                    D: "div",
                    T: "ytp-countdown-timer",
                    Z: [{
                        D: "svg",
                        Y: {
                            height: "100%",
                            version: "1.1",
                            viewBox: "0 0 72 72",
                            width: "100%"
                        },
                        Z: [{
                            D: "circle",
                            T: "ytp-svg-countdown-timer-ring",
                            Y: {
                                cx: "-36",
                                cy: "36",
                                "fill-opacity": "0",
                                r: "33.5",
                                stroke: "#FFFFFF",
                                "stroke-dasharray": "211",
                                "stroke-dashoffset": "-211",
                                "stroke-width": "4",
                                transform: "rotate(-90)"
                            }
                        }, {
                            D: "circle",
                            T: "ytp-svg-countdown-timer-background",
                            Y: {
                                cx: "-36",
                                cy: "36",
                                "fill-opacity": "0",
                                r: "33.5",
                                stroke: "#FFFFFF",
                                "stroke-opacity": "0.3",
                                "stroke-width": "4",
                                transform: "rotate(-90)"
                            }
                        }]
                    }, {
                        D: "span",
                        T: "ytp-countdown-timer-time",
                        E8: "{{duration}}"
                    }]
                }]
            });
            this.api = m;
            this.X = this.Lf("ytp-svg-countdown-timer-ring");
            this.j = null;
            this.L = this.K = 0;
            this.V = !1;
            this.B = 0;
            this.api.createClientVe(this.element, this, 159628)
        },
        fyS = function(m) {
            m.j || (m.K = 5E3, m.L = (0, g.Kq)(), m.j = new g.px(function() {
                Yna(m)
            }, null), Yna(m))
        },
        Yna = function(m) {
            if (!m.V) {
                var c = Math.min((0, g.Kq)() - m.L, m.K);
                var W = m.K - c;
                c = m.K === 0 ? 0 : Math.max(W / m.K, 0);
                W = Math.round(W / 1E3);
                m.X.setAttribute("stroke-dashoffset", "" + -211 * (c + 1));
                m.updateValue("duration", W);
                c <= 0 && m.j ? AO(m) : m.j && m.j.start()
            }
        },
        AO = function(m) {
            m.j && (m.j.dispose(), m.j = null, m.V = !1)
        },
        Iyh = function(m) {
            g.dg.call(this, m);
            this.C = m;
            this.j = new g.nm(this);
            this.V = null;
            this.X = !1;
            this.countdownTimer = null;
            this.W = !1;
            iEH(this);
            g.r(this, this.j);
            this.load()
        },
        Uqc = function(m) {
            var c = g.ZQN(m.C);
            c !== m.W && (m.W = c, m.U && (m.U.dispose(), m.U = null), m.K && (m.K.dispose(), m.K = null), m.L && (m.L.dispose(), m.L = null), m.V && (m.V.stop(), m.V.dispose(), m.V = null), c && (c = g.MT(m.C), m.C.isEmbedsShortsMode() && (m.L = new g.f({
                D: "div",
                T: "ytp-pause-overlay-backdrop",
                Y: {
                    tabIndex: "-1"
                }
            }), g.r(m, m.L), g.zi(m.C, m.L.element, 4), m.V = new g.Rd(m.L, 1E3, !1, 100), g.r(m, m.V), m.L.hide()), m.U = new g.f({
                D: "div",
                T: "ytp-pause-overlay-container",
                Y: {
                    tabIndex: "-1"
                }
            }), g.r(m, m.U), m.K = new cu(m.C, c), g.r(m, m.K), m.K.s8(m.U.element), g.zi(m.C, m.U.element,
                4), PSh(m, m.C.getPlayerStateObject())))
        },
        PSh = function(m, c) {
            m.V && (!g.U(c, 4) && !g.U(c, 2) || g.U(c, 1024) ? m.V.hide() : m.V.show())
        },
        iEH = function(m) {
            var c = m.C;
            m = !!c.isEmbedsShortsMode();
            g.wY(c.getRootNode(), "ytp-shorts-mode", m);
            if (c = c.getVideoData()) c.J0 = m
        },
        pk = function(m, c) {
            var W = m.C.J();
            m = {
                adSource: "EMBEDS_AD_SOURCE_YOUTUBE",
                breakType: m.C.getCurrentTime() === 0 ? "EMBEDS_AD_BREAK_TYPE_PRE_ROLL" : m.C.getPlayerState() === 0 ? "EMBEDS_AD_BREAK_TYPE_POST_ROLL" : "EMBEDS_AD_BREAK_TYPE_MID_ROLL",
                embedUrl: g.VHm(m.C.J().loaderUrl),
                eventType: c,
                youtubeHost: g.St(m.C.J().De) || ""
            };
            m.embeddedPlayerMode = W.il;
            g.Q8("embedsAdEvent", m)
        };
    g.J(t74, g.f);
    g.O = t74.prototype;
    g.O.hide = function() {
        this.X = !0;
        g.f.prototype.hide.call(this);
        GXS(this, !1)
    };
    g.O.show = function() {
        this.X = !1;
        g.f.prototype.show.call(this);
        GXS(this, !0)
    };
    g.O.isHidden = function() {
        return this.X
    };
    g.O.GR = function() {
        this.scrollTo(this.scrollPosition - this.containerWidth)
    };
    g.O.Xj = function() {
        this.scrollTo(this.scrollPosition + this.containerWidth)
    };
    g.O.resize = function(m, c) {
        var W = this.api.J(),
            A = 16 / 9,
            p = m.width >= 650,
            R = m.width < 480 || m.height < 290,
            L = Math.min(this.suggestionData.length, this.j.length);
        if (Math.min(m.width, m.height) <= 150 || L === 0 || !W.pm) this.hide();
        else {
            var M;
            if (p) {
                var b = M = 28;
                this.V = 16
            } else this.V = b = M = 8;
            if (R) {
                var N = 6;
                p = 14;
                var Z = 12;
                R = 24;
                W = 12
            } else N = 8, p = 18, Z = 16, R = 36, W = 16;
            m = m.width - (48 + M + b);
            M = Math.ceil(m / 150);
            M = Math.min(3, M);
            b = m / M - this.V;
            var F = Math.floor(b / A);
            c && F + 100 > c && b > 50 && (F = Math.max(c, 50 / A), M = Math.ceil(m / (A * (F - 100) + this.V)), b = m / M - this.V,
                F = Math.floor(b / A));
            b < 50 || g.l6(this.api) ? this.hide() : this.show();
            for (c = 0; c < L; c++) {
                A = this.j[c];
                var Q = A.Lf("ytp-suggestion-image");
                Q.style.width = b + "px";
                Q.style.height = F + "px";
                A.Lf("ytp-suggestion-title").style.width = b + "px";
                A.Lf("ytp-suggestion-author").style.width = b + "px";
                A = A.Lf("ytp-suggestion-duration");
                A.style.display = A && b < 100 ? "none" : ""
            }
            L = p + N + Z + 4;
            this.B = L + W + (F - R) / 2;
            this.suggestions.element.style.height = F + L + "px";
            this.K = b;
            this.containerWidth = m;
            this.columns = M;
            this.scrollPosition = 0;
            this.suggestions.element.scrollLeft = -0;
            DqH(this)
        }
    };
    g.O.onVideoDataChange = function() {
        var m = this.api.getVideoData(),
            c = this.api.J();
        this.N = m.MU ? !1 : c.L;
        m.suggestions ? this.suggestionData = g.w6(m.suggestions, function(W) {
            return W && !W.playlistId
        }) : this.suggestionData.length = 0;
        Kdh(this);
        m.MU ? this.title.update({
            title: g.xg("More videos from $DNI_RELATED_CHANNEL", {
                DNI_RELATED_CHANNEL: m.author
            })
        }) : this.title.update({
            title: "More videos on YouTube"
        })
    };
    g.O.scrollTo = function(m) {
        m = g.Zd(m, this.containerWidth - this.suggestionData.length * (this.K + this.V), 0);
        this.W.start(this.scrollPosition, m, 1E3);
        this.scrollPosition = m;
        DqH(this);
        GXS(this, !0)
    };
    g.J(UE, g.PL);
    UE.prototype.show = function() {
        g.PL.prototype.show.call(this);
        vii(this, this.api.FY().getPlayerSize())
    };
    UE.prototype.resize = function(m) {
        g.PL.prototype.resize.call(this, m);
        this.j && (vii(this, m), g.wY(this.element, "related-on-error-overlay-visible", !this.j.isHidden()))
    };
    UE.prototype.V = function(m) {
        g.PL.prototype.V.call(this, m);
        var c = this.api.getVideoData();
        if (c.yZ || c.playerErrorMessageRenderer)(m = c.yZ) ? uRi(this, m) : c.playerErrorMessageRenderer && uRi(this, c.playerErrorMessageRenderer);
        else {
            var W;
            m.MG && (c.I6 ? jCG(c.I6) ? W = g.Hi(c.I6) : W = g.Ua(g.V9(c.I6)) : W = g.Ua(m.MG), this.jK(W, "subreason"))
        }
    };
    g.J(nid, g.f);
    g.O = nid.prototype;
    g.O.onVideoDataChange = function() {
        var m = this.api.getVideoData(),
            c = eid(),
            W = 96714;
        g.P2(m) ? (c = dqd(), W = 216165, g.ov(this.element, "ytp-music-impression-link")) : g.QM(this.element, "ytp-music-impression-link");
        this.api.J().G("embeds_enable_emc3ds_woyt_counterfactual") && g.ov(this.element, "ytp-woyt-emc3ds-cf");
        this.updateValue("logoSvg", c);
        this.api.hasVe(this.element) && this.api.destroyVe(this.element);
        this.api.createClientVe(this.element, this, W)
    };
    g.O.X$ = function() {
        this.api.getPlayerStateObject().isCued() || (this.hide(), this.api.logVisibility(this.element, !1))
    };
    g.O.Zp = function() {
        var m = this.api.getVideoData(),
            c = this.api.J(),
            W = this.api.getVideoData().MU,
            A = c.HB && !c.G("embeds_enable_emc3ds_woyt_counterfactual"),
            p = !c.pm,
            R = this.j.uK() && !c.G("embeds_enable_emc3ds_woyt_counterfactual");
        c = c.K;
        A || R || W || p || c || this.api.isEmbedsShortsMode() || !m.videoId ? (this.hide(), this.api.logVisibility(this.element, !1)) : (m = rgS(this), this.updateValue("url", m), this.show())
    };
    g.O.onClick = function(m) {
        this.api.G("web_player_log_click_before_generating_ve_conversion_params") && this.api.logClick(this.element);
        var c = rgS(this);
        g.mq(c, this.api, m);
        this.api.G("web_player_log_click_before_generating_ve_conversion_params") || this.api.logClick(this.element)
    };
    g.O.show = function() {
        this.api.getPlayerStateObject().isCued() && (g.f.prototype.show.call(this), this.api.hasVe(this.element) && this.api.logVisibility(this.element, !0))
    };
    g.J(kH, g.f);
    kH.prototype.X$ = function() {
        var m = this.api.getPlayerStateObject();
        !this.api.ea() || g.U(m, 2) && g.Vu(this.api) || g.U(m, 64) ? (this.api.logVisibility(this.j, !1), this.api.logVisibility(this.forwardButton, !1), this.hide()) : (this.show(), this.api.logVisibility(this.j, !0), this.api.logVisibility(this.forwardButton, !0))
    };
    kH.prototype.V = function() {
        this.api.seekBy(-10 * this.api.getPlaybackRate(), void 0, void 0, 83);
        this.api.logClick(this.j)
    };
    kH.prototype.K = function() {
        this.api.seekBy(10 * this.api.getPlaybackRate(), void 0, void 0, 82);
        this.api.logClick(this.forwardButton)
    };
    g.J(XC, g.f);
    XC.prototype.K = function() {
        var m = this.api.getPlayerStateObject(),
            c = this.api.getVideoData();
        this.api.J().G("embeds_enable_muted_autoplay_shorts_endscreen_fix") && g.wY(this.element, "ytp-shorts-mode", this.api.isEmbedsShortsMode());
        !c.mutedAutoplay || this.api.G("embeds_enable_full_length_inline_muted_autoplay") && c.limitedPlaybackDurationInSeconds === 0 && c.endSeconds === 0 || (g.U(m, 2) && !this.d4 ? (this.show(), this.j || (this.j = new g.iq(this.api), g.r(this, this.j), this.j.s8(this.L, 0), this.j.show()), m = this.api.getVideoData(), this.updateValue("text",
            m.XQ), g.wY(this.element, "ytp-muted-autoplay-show-end-panel", !0), this.api.logVisibility(this.element, this.d4), this.api.rT("onMutedAutoplayEnds")) : this.hide())
    };
    XC.prototype.onClick = function() {
        if (!this.V) {
            this.j && (this.j.xo(), this.j = null);
            g.wY(this.api.getRootNode(), "ytp-muted-autoplay", !1);
            var m = this.api.getVideoData(),
                c = this.api.getCurrentTime();
            ziH(m);
            this.api.loadVideoById(m.videoId, c);
            this.api.Gg();
            this.api.logClick(this.element);
            this.hide();
            this.V = !0
        }
    };
    XC.prototype.onMutedAutoplayStarts = function() {
        this.V = !1;
        this.j && (this.j.xo(), this.j = null)
    };
    g.J(m_, g.f);
    g.O = m_.prototype;
    g.O.onStateChange = function(m) {
        this.aB(m.state)
    };
    g.O.aB = function(m) {
        this.state !== m && (this.state = m);
        hii(this)
    };
    g.O.onVideoDataChange = function() {
        var m = this.api.J();
        m.K && g.ov(this.element, "ytp-no-hover");
        var c = this.api.getVideoData();
        c.videoId && !m.K ? (m = this.api.getVideoUrl(!0, !1, !1, !0), this.updateValue("url", m), this.j || (this.j = this.listen("click", this.onClick))) : this.j && (this.updateValue("url", null), this.BE(this.j), this.j = null);
        m = eid();
        var W = 76758;
        g.P2(c) && (m = dqd(), W = 216164);
        this.updateValue("logoSvg", m);
        this.api.hasVe(this.element) && this.api.destroyVe(this.element);
        this.api.createClientVe(this.element, this,
            W);
        hii(this)
    };
    g.O.onClick = function(m) {
        this.api.G("web_player_log_click_before_generating_ve_conversion_params") && this.api.logClick(this.element);
        var c = this.api.getVideoUrl(!g.du(m), !1, !0, !0);
        if (this.api.G("web_player_log_click_before_generating_ve_conversion_params")) {
            var W = {};
            g.AM(this.api, "addEmbedsConversionTrackingParams", [W]);
            c = g.PX(c, W)
        }
        g.mq(c, this.api, m);
        this.api.G("web_player_log_click_before_generating_ve_conversion_params") || this.api.logClick(this.element)
    };
    g.O.Fz = function(m) {
        if ((m = m.width < 480) && !this.V || !m && this.V) {
            var c = new g.f(eid()),
                W = this.Lf("ytp-watermark");
            g.wY(W, "ytp-watermark-small", m);
            g.LE(W);
            c.s8(W);
            this.V = m
        }
    };
    g.J(Eir, g.f);
    g.O = Eir.prototype;
    g.O.dY = function() {
        var m = this.api.getPlayerStateObject();
        !this.api.getVideoData().mutedAutoplay || g.U(m, 2) ? this.hide() : this.d4 || (g.f.prototype.show.call(this), this.api.logVisibility(this.element, this.d4))
    };
    g.O.q8q = function() {
        this.j && this.j.hide()
    };
    g.O.onAutoplayBlocked = function() {
        this.hide();
        ziH(this.api.getVideoData())
    };
    g.O.onClick = function() {
        if (!this.V) {
            g.wY(this.api.getRootNode(), "ytp-muted-autoplay", !1);
            var m = this.api.getVideoData(),
                c = this.api.getCurrentTime();
            ziH(m);
            this.api.loadVideoById(m.videoId, c);
            this.api.Gg();
            this.api.logClick(this.element);
            this.api.rT("onMutedAutoplayEnds");
            this.V = !0
        }
    };
    g.O.onMutedAutoplayEnds = function() {
        this.watermark && (this.watermark.xo(), this.watermark = null)
    };
    g.J(cu, g.f);
    cu.prototype.hide = function() {
        g.QM(this.api.getRootNode(), "ytp-expand-pause-overlay");
        g.f.prototype.hide.call(this)
    };
    cu.prototype.B = function() {
        this.V = !0;
        g.QM(this.api.getRootNode(), "ytp-expand-pause-overlay");
        this.api.isEmbedsShortsMode() && this.api.logVisibility(this.element, !1);
        this.expandButton.focus()
    };
    cu.prototype.X = function() {
        this.V = !1;
        g.ov(this.api.getRootNode(), "ytp-expand-pause-overlay");
        this.api.isEmbedsShortsMode() && this.api.logVisibility(this.element, !0);
        this.focus()
    };
    cu.prototype.Ps = function() {
        var m = this.api.getPlayerStateObject();
        g.U(m, 1) || g.U(m, 16) || g.U(m, 32) || (!g.U(m, 4) || g.U(m, 2) || g.U(m, 1024) ? (this.V || this.api.logVisibility(this.element, !1), this.L.hide()) : this.j.hasSuggestions() && (this.V || (g.ov(this.api.getRootNode(), "ytp-expand-pause-overlay"), g.I7(this.j), this.j.show(), this.api.logVisibility(this.element, !0)), this.L.show()))
    };
    g.J(Wu, g.f);
    Wu.prototype.show = function() {
        g.f.prototype.show.call(this);
        this.api.logVisibility(this.element, !0)
    };
    Wu.prototype.xo = function() {
        AO(this);
        g.f.prototype.xo.call(this)
    };
    g.J(Iyh, g.dg);
    g.O = Iyh.prototype;
    g.O.yf = function() {
        return !1
    };
    g.O.create = function() {
        var m = this.C.J(),
            c = g.MT(this.C),
            W, A = (W = this.C.getVideoData()) == null ? void 0 : W.clientPlaybackNonce;
        A && g.Yk({
            clientPlaybackNonce: A
        });
        m.Iq && !m.disableOrganicUi && Uqc(this);
        var p;
        this.C.G("embeds_enable_emc3ds_muted_autoplay") && ((p = m.getWebPlayerContextConfig()) == null ? 0 : p.embedsEnableEmc3ds) || (this.N = new Eir(this.C), g.r(this, this.N), g.zi(this.C, this.N.element, 4), this.Mh = new XC(this.C), g.r(this, this.Mh), g.zi(this.C, this.Mh.element, 4));
        m.HB && (this.watermark = new m_(this.C), g.r(this, this.watermark),
            g.zi(this.C, this.watermark.element, 8));
        c && !m.disableOrganicUi && (this.B = new nid(this.C, c), g.r(this, this.B), g.zi(this.C, this.B.element, 8), this.C.isMutedByEmbedsMutedAutoplay() && (this.onMutedAutoplayStarts(), this.B.hide()));
        m.V && !m.disableOrganicUi && (this.Vb = new kH(this.C), g.r(this, this.Vb), g.zi(this.C, this.Vb.element, 4));
        this.j.S(this.C, "appresize", this.Fz);
        this.j.S(this.C, "presentingplayerstatechange", this.X$);
        this.j.S(this.C, "videodatachange", this.onVideoDataChange);
        this.j.S(this.C, "videoplayerreset",
            this.onReset);
        this.j.S(this.C, "onMutedAutoplayStarts", this.onMutedAutoplayStarts);
        this.j.S(this.C, "onAdStart", this.onAdStart);
        this.j.S(this.C, "onAdComplete", this.onAdComplete);
        this.j.S(this.C, "onAdSkip", this.onAdSkip);
        this.j.S(this.C, "onAdStateChange", this.onAdStateChange);
        if (this.X = g.g2(g.Dq(m))) this.countdownTimer = new Wu(this.C), g.r(this, this.countdownTimer), g.zi(this.C, this.countdownTimer.element, 4), this.countdownTimer.hide(), this.j.S(this.C, g.$g("embeds"), this.onCueRangeEnter), this.j.S(this.C,
            g.N9("embeds"), this.onCueRangeExit);
        this.Lm(this.C.getPlayerStateObject());
        this.player.XN("embed");
        var R, L;
        ((R = this.C.J().getWebPlayerContextConfig()) == null ? 0 : (L = R.embedsHostFlags) == null ? 0 : L.allowOverridingVisitorDataPlayerVars) && (m = g.cP("IDENTITY_MEMENTO")) && this.C.zF("onMementoChange", m)
    };
    g.O.onCueRangeEnter = function(m) {
        m.getId() === "countdown timer" && this.countdownTimer && (this.countdownTimer.show(), fyS(this.countdownTimer))
    };
    g.O.onCueRangeExit = function(m) {
        m.getId() === "countdown timer" && this.countdownTimer && (AO(this.countdownTimer), this.countdownTimer.hide())
    };
    g.O.Fz = function() {
        var m = this.C.FY().getPlayerSize();
        this.h8 && this.h8.resize(m)
    };
    g.O.onReset = function() {
        iEH(this)
    };
    g.O.X$ = function(m) {
        this.Lm(m.state)
    };
    g.O.Lm = function(m) {
        g.U(m, 128) ? (this.h8 || (this.h8 = new UE(this.C), g.r(this, this.h8), g.zi(this.C, this.h8.element, 4)), this.h8.V(m.ox), this.h8.show(), g.ov(this.C.getRootNode(), "ytp-embed-error")) : this.h8 && (this.h8.dispose(), this.h8 = null, g.QM(this.C.getRootNode(), "ytp-embed-error"));
        if (this.countdownTimer && this.countdownTimer.j)
            if (g.U(m, 64)) this.countdownTimer.hide(), AO(this.countdownTimer);
            else if (m.isPaused()) {
            var c = this.countdownTimer;
            c.V || (c.V = !0, c.B = (0, g.Kq)())
        } else m.isPlaying() && this.countdownTimer.V &&
            (c = this.countdownTimer, c.V && (c.L += (0, g.Kq)() - c.B, c.V = !1, Yna(c)));
        PSh(this, m)
    };
    g.O.onMutedAutoplayStarts = function() {
        this.C.getVideoData().mutedAutoplay && this.N && g.wY(this.C.getRootNode(), "ytp-muted-autoplay", !0)
    };
    g.O.onVideoDataChange = function(m, c) {
        var W = this.P8 !== c.videoId;
        m = !W && m === "dataloaded";
        var A = {
            isShortsModeEnabled: !!this.C.isEmbedsShortsMode()
        };
        g.Q8("embedsVideoDataDidChange", {
            clientPlaybackNonce: c.clientPlaybackNonce,
            isReload: m,
            runtimeEnabledFeatures: A
        });
        W && (this.P8 = c.videoId, this.countdownTimer && (this.countdownTimer.show(), this.countdownTimer.hide()), this.X && (this.C.IX("embeds"), c.isAd() || c.limitedPlaybackDurationInSeconds < 5 || g.l6(this.C) || (c = Math.max((c.startSeconds + c.limitedPlaybackDurationInSeconds -
            5) * 1E3, 0), c = new g.M9(c, c + 5E3, {
            id: "countdown timer",
            namespace: "embeds"
        }), this.C.jS([c]))), this.C.J().Iq && !this.C.J().disableOrganicUi && (iEH(this), Uqc(this)));
        this.C.J().K && this.K && this.K.detach()
    };
    g.O.onAdStart = function() {
        pk(this, "EMBEDS_AD_EVENT_TYPE_AD_STARTED")
    };
    g.O.onAdComplete = function() {
        pk(this, "EMBEDS_AD_EVENT_TYPE_AD_COMPLETED")
    };
    g.O.onAdSkip = function() {
        pk(this, "EMBEDS_AD_EVENT_TYPE_AD_SKIPPED")
    };
    g.O.onAdStateChange = function(m) {
        m === 2 && pk(this, "EMBEDS_AD_EVENT_TYPE_AD_PAUSED")
    };
    g.e$("embed", Iyh);
})(_yt_player);